#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(void)
{
    int n=10,i;
    int f = 1;
    #pragma
        for(i=1;i<=n;i++){
            f*=i;
        }
        printf("Tread %d - f(%d)=%d\n",omp_get_thread_num(),n,f);
        return 0;
}
